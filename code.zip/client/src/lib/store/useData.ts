import { useState, useEffect, useCallback, useRef } from 'react';
import { getDataStore, getUserId, genId } from './index';
import type { IDataStore, ExportData, ImportResult } from './index';
import type { ITransaction, IChatMessage } from '@/data/transaction';
import { logger } from '@lark-apaas/client-toolkit';

interface UseDataState {
  loading: boolean;
  store: IDataStore | null;
  userId: string;
}

interface UseDataReturn extends UseDataState {
  transactions: ITransaction[];
  addTransaction: (tx: Omit<ITransaction, 'id' | 'userId' | 'createdAt'>) => Promise<string>;
  addTransactions: (txs: Array<Omit<ITransaction, 'id' | 'userId' | 'createdAt'>>) => Promise<string[]>;
  removeTransaction: (id: string) => Promise<void>;
  refreshTransactions: () => Promise<void>;

  messages: IChatMessage[];
  addMessage: (msg: any) => Promise<string>;
  updateMessageContent: (id: string, content: string) => Promise<void>;
  refreshMessages: () => Promise<void>;

  getSummary: (date: string) => Promise<string | null>;
  saveSummary: (date: string, summary: string) => Promise<void>;

  exportData: () => Promise<ExportData>;
  importData: (data: ExportData) => Promise<ImportResult>;
}

export function useData(): UseDataReturn {
  const [state, setState] = useState<UseDataState>({
    loading: true,
    store: null,
    userId: '',
  });

  const [transactions, setTransactions] = useState<ITransaction[]>([]);
  const [messages, setMessages] = useState<IChatMessage[]>([]);

  const storeRef = useRef<IDataStore | null>(null);
  const userIdRef = useRef<string>('');

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const [userId, store] = await Promise.all([
          getUserId(),
          getDataStore(),
        ]);

        if (cancelled) return;

        storeRef.current = store;
        userIdRef.current = userId;

        const [txs, msgs] = await Promise.all([
          store.listTransactions(userId),
          store.listMessages(userId),
        ]);

        if (cancelled) return;

        setTransactions(txs);
        setMessages(msgs);
        setState({
          loading: false,
          store,
          userId,
        });
      } catch (err) {
        logger.error('useData init error:', String(err));
        if (!cancelled) {
          setState((s) => ({ ...s, loading: false }));
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const refreshTransactions = useCallback(async () => {
    if (!storeRef.current || !userIdRef.current) return;
    try {
      const txs = await storeRef.current.listTransactions(userIdRef.current);
      setTransactions(txs);
    } catch (err) {
      logger.error('refreshTransactions error:', String(err));
    }
  }, []);

  const addTransaction = useCallback(async (
    tx: Omit<ITransaction, 'id' | 'userId' | 'createdAt'>
  ): Promise<string> => {
    if (!storeRef.current || !userIdRef.current) {
      throw new Error('Data store not ready');
    }
    const id = genId('tx');
    const newTx: ITransaction = {
      ...tx,
      id,
      userId: userIdRef.current,
      createdAt: Date.now(),
    };
    await storeRef.current.createTransaction(newTx);
    setTransactions((prev) => [newTx, ...prev].sort((a, b) => b.createdAt - a.createdAt));
    return id;
  }, []);

  const addTransactions = useCallback(async (
    txs: Array<Omit<ITransaction, 'id' | 'userId' | 'createdAt'>>
  ): Promise<string[]> => {
    if (!storeRef.current || !userIdRef.current) {
      throw new Error('Data store not ready');
    }
    const now = Date.now();
    const newTxs: ITransaction[] = txs.map((t, i) => ({
      ...t,
      id: genId('tx'),
      userId: userIdRef.current,
      createdAt: now + i,
    }));
    await storeRef.current.createTransactions(newTxs);
    setTransactions((prev) =>
      [...newTxs, ...prev].sort((a, b) => b.createdAt - a.createdAt)
    );
    return newTxs.map((t) => t.id);
  }, []);

  const removeTransaction = useCallback(async (id: string): Promise<void> => {
    if (!storeRef.current || !userIdRef.current) return;
    try {
      await storeRef.current.deleteTransaction(userIdRef.current, id);
      setTransactions((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      logger.error('removeTransaction error:', String(err));
      throw err;
    }
  }, []);

  const refreshMessages = useCallback(async () => {
    if (!storeRef.current || !userIdRef.current) return;
    try {
      const msgs = await storeRef.current.listMessages(userIdRef.current);
      setMessages(msgs);
    } catch (err) {
      logger.error('refreshMessages error:', String(err));
    }
  }, []);

  const addMessage = useCallback(async (
    msg: any
  ): Promise<string> => {
    if (!storeRef.current || !userIdRef.current) {
      throw new Error('Data store not ready');
    }
    const id = msg.id || genId('msg');
    const newMsg: IChatMessage = {
      ...msg,
      id,
      userId: userIdRef.current,
      timestamp: msg.timestamp ?? Date.now(),
    };
    await storeRef.current.createMessage(newMsg);
    setMessages((prev) => [...prev, newMsg].sort((a, b) => a.timestamp - b.timestamp));
    return id;
  }, []);

  const updateMessageContent = useCallback(async (
    id: string,
    content: string
  ): Promise<void> => {
    if (!storeRef.current || !userIdRef.current) return;
    setMessages((prev) => {
      const msg = prev.find((m) => m.id === id);
      if (!msg) return prev;
      const updated = { ...msg, content };
      storeRef.current?.updateMessage(updated).catch((err) => {
        logger.error('updateMessageContent error:', String(err));
      });
      return prev.map((m) => (m.id === id ? updated : m));
    });
  }, []);

  const getSummary = useCallback(async (date: string): Promise<string | null> => {
    if (!storeRef.current || !userIdRef.current) return null;
    return storeRef.current.getDailySummary(userIdRef.current, date);
  }, []);

  const saveSummary = useCallback(async (date: string, summary: string): Promise<void> => {
    if (!storeRef.current || !userIdRef.current) return;
    await storeRef.current.saveDailySummary(userIdRef.current, date, summary);
  }, []);

  const exportData = useCallback(async (): Promise<ExportData> => {
    if (!storeRef.current || !userIdRef.current) {
      throw new Error('Data store not ready');
    }
    return storeRef.current.exportAll(userIdRef.current);
  }, []);

  const importData = useCallback(async (data: ExportData): Promise<ImportResult> => {
    if (!storeRef.current || !userIdRef.current) {
      throw new Error('Data store not ready');
    }
    const result = await storeRef.current.importAll(userIdRef.current, data);
    const [txs, msgs] = await Promise.all([
      storeRef.current.listTransactions(userIdRef.current),
      storeRef.current.listMessages(userIdRef.current),
    ]);
    setTransactions(txs);
    setMessages(msgs);
    return result;
  }, []);

  return {
    ...state,
    transactions,
    messages,
    addTransaction,
    addTransactions,
    removeTransaction,
    refreshTransactions,
    addMessage,
    updateMessageContent,
    refreshMessages,
    getSummary,
    saveSummary,
    exportData,
    importData,
  };
}
