import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  TransactionDTO, ChatMessageDTO,
  ListTransactionsResponse,
  CreateTransactionsResponse,
  ListMessagesResponse,
  CreateMessagesResponse,
  GetSummaryResponse, SaveSummaryResponse,
  ImportAllRequest, ImportAllResponse,
} from '@shared/api.interface';

export async function listTransactions(): Promise<TransactionDTO[]> {
  const res = await axiosForBackend.get<ListTransactionsResponse>(
    '/api/rolly/transactions'
  );
  return res.data.items;
}

export async function createTransactions(
  transactions: TransactionDTO[]
): Promise<number> {
  const res = await axiosForBackend.post<CreateTransactionsResponse>(
    '/api/rolly/transactions',
    { transactions }
  );
  return res.data.createdCount;
}

export async function deleteTransaction(id: string): Promise<void> {
  await axiosForBackend.delete(`/api/rolly/transactions/${id}`);
}

export async function listMessages(): Promise<ChatMessageDTO[]> {
  const res = await axiosForBackend.get<ListMessagesResponse>(
    '/api/rolly/messages'
  );
  return res.data.items;
}

export async function createMessages(
  messages: ChatMessageDTO[]
): Promise<number> {
  const res = await axiosForBackend.post<CreateMessagesResponse>(
    '/api/rolly/messages',
    { messages }
  );
  return res.data.createdCount;
}

export async function updateMessage(
  id: string,
  content: string
): Promise<void> {
  await axiosForBackend.patch(`/api/rolly/messages/${id}`, {
    content,
  });
}

export async function getSummary(
  date: string
): Promise<GetSummaryResponse> {
  const res = await axiosForBackend.get<GetSummaryResponse>(
    `/api/rolly/summaries?date=${date}`
  );
  return res.data;
}

export async function saveSummary(
  date: string,
  summary: string
): Promise<void> {
  await axiosForBackend.put<SaveSummaryResponse>(
    '/api/rolly/summaries',
    { date, summary }
  );
}

export async function importAll(
  data: ImportAllRequest
): Promise<ImportAllResponse> {
  const res = await axiosForBackend.post<ImportAllResponse>(
    '/api/rolly/import',
    data
  );
  return res.data;
}