# 工作区记忆

## Web Speech API 按住说话录音失败（pointer 事件 + 异步权限 + 布局变化冲突）

- 现象：点麦克风后短暂"正在录音"随即失败；pointerdown 启动录音、pointerup 结束的方案在移动端不稳定
- 根因：① 首次点击 getUserMedia 权限异步等待，pointerup 先于 start() 触发，录音启动后无人结束；② 普通点击按住时长太短录不到语音；③ isRecording 变 true 时插入提示条/换图标引起触摸点 pointercancel/pointerleave，直接掐断录音
- 修复：改为 onClick 点按切换（点一下开始、再点一下 stop），识别结果统一在 rec.onend 回调结算提交（submitVoiceTextRef 保持最新 handler），权限申请放在改 UI 状态之前；ChatPage.tsx handleMicClick
